# modules/data_loading.py
import os
import pandas as pd
import logging

""" load the csv files and convert them into pandas datafarmes """
def load_csv(file_path):
    try:
        return pd.read_csv(file_path)
    except Exception as e:
        logging.info(e)
        return False
