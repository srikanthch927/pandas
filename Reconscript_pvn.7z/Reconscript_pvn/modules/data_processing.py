# modules/data_processing.py
import re

# filter the dataframe and neglect the columns which has void status
def filter_clearport(df):
    return df[df['Status'] != 'Void']

#  calculate product_convention by merging columns Product,Term in clearport file to compare both csv files 
def calculate_product_convention(row):
    return row['Product'] + row['Term']

def remove_special_symbols(text):
    return re.sub(r'[^\w\s]', '', text)
    
# modify clearport file to match with manualfills file 
def preprocess_clearport(df):
    df['ProductConvention'] = df.apply(calculate_product_convention, axis=1)
    df['Quantity'] = df['Quantity'].astype(str).str.replace(',', '').astype(int)
    df['Product'] = df['Product'].astype(str)
    
    df['Term'] = df['Term'].apply(remove_special_symbols)
    df['Term'] = df['Term'].str.replace('20', '')

    df['Contract'] = df['Product'].apply(lambda x: x.split()[-1][1:3]) + ' ' + df['Term']

    return df

# convert quantity into gallons for uniformity in data
def convert_quantity_to_gallons(df):
    for idx, value in df['Quantity'].items():
        if value > 1000:
            df.at[idx, 'Quantity'] = int(value) / 42000
    return df
