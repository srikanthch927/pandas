# modules/reconciliation.py
import pandas as pd
from modules.data_processing import filter_clearport, preprocess_clearport, convert_quantity_to_gallons
import os
import logging

""" reconciliation between two dataframes based on four columns (contract,price,side,quantity)  
and create new dataframe  called reconciled_df """
def reconcile_dataframes(date):
    file_path = os.path.expanduser("~\\pandass\\")
   
    manualfills_file = 'manualfillsTT_{}.csv'.format(date)
  
    clearport_file = 'clearport_{}.csv'.format(date)

    try:
        manualfills_df = pd.read_csv(file_path+manualfills_file)
    except Exception as e:
        logging.info("File not found")

    clearport_df = pd.read_csv(file_path+clearport_file)
    
    clearport_df = filter_clearport(clearport_df)
    clearport_df = preprocess_clearport(clearport_df)
    clearport_df = convert_quantity_to_gallons(clearport_df)
    reconciled_df = pd.merge(manualfills_df,clearport_df,on=['Contract','Price','Side','Quantity'],how='inner',indicator=True)

    """ dataframes created by grouping the columns on basis of quantity aggregate and merged both dataframes to form new dataframe """
    df1_temp = manualfills_df.groupby(by=['Contract','Side','Price']).agg({'Quantity': 'sum'}).reset_index()
    df2_temp = clearport_df.groupby(by=['Contract','Side','Price']).agg({'Quantity': 'sum'}).reset_index()
    return_df = pd.merge(df1_temp, df2_temp,on=['Contract','Side','Price','Quantity'], how='left', indicator=True)
    return_df = return_df[return_df['_merge']!='both']
    
    logging.info(reconciled_df)
    
    return return_df