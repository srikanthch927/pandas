# modules/utils.py
import os
import logging
import datetime

def setup_logging():
    filename = os.path.abspath(__file__).split("/")[-1].split(".py")[0] + "_" \
               + datetime.datetime.now().strftime('%m%d%y_%H%M%S')

    execution_log = filename + ".log"

    logging.basicConfig(filename=execution_log, level=logging.INFO,
                        format='%(asctime)s:%(levelname)s: %(message)s', datefmt='%m%d%y %H:%M:%S')

    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    formatter = logging.Formatter('%(levelname)s: %(message)s')
    console.setFormatter(formatter)
    logging.getLogger('').addHandler(console)
