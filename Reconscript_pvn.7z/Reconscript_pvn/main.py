# main_script.py

from modules.reconciliation import reconcile_dataframes
from logs.log import setup_logging
import logging


if __name__ == '__main__':
    
    try:
        setup_logging()

        """Enter the required date for file  ex:20230929"""
        date='20230929'
        # date=input('enter date:')
        return_df = reconcile_dataframes(date)
        
        if len(return_df) == 0:
            logging.info('recon matched')
        else:
            logging.info('recon failed')

    except Exception as e:
        logging.info(e)
        raise